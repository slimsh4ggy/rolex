#!/system/bin/sh

R=/sys/class/leds/red/brightness
G=/sys/class/leds/green/brightness
B=/sys/class/leds/blue/brightness

fade() {
  r1=$1; g1=$2; b1=$3
  r2=$4; g2=$5; b2=$6

  i=0
  while [ "$i" -le 20 ]; do
    echo $((r1+(r2-r1)*i/20)) > "$R"
    echo $((g1+(g2-g1)*i/20)) > "$G"
    echo $((b1+(b2-b1)*i/20)) > "$B"
    sleep 0.04
    i=$((i+1))
  done
}

while true; do
  fade 200 0 0   200 0 200
  fade 200 0 200 0 0 200
  fade 0 0 200   0 200 200
  fade 0 200 200 0 200 0
  fade 0 200 0   200 200 0
  fade 200 200 0 200 0 0
done
